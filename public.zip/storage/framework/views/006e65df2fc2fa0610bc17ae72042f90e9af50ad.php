<?php $__env->startSection('title_pag'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<h1 class="h3 mb-0 text-gray-800">Dashboassrd</h1>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col">
        Holaa
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Proyectos Personales\pago\El que me paga cada miercoles\parkingZoneAdmin\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>