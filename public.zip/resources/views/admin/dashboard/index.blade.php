@extends('layouts.admin.index')
@section('title_pag')
    Dashboard
@endsection
@section('title')
<h1 class="h3 mb-0 text-gray-800">Dashboassrd</h1>

@endsection
@section('css')

@endsection
@section('content')
<div class="row">
    <div class="col">
        Holaa
    </div>
</div>
@endsection
@section('script')

@endsection
